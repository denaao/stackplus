# 👤 Perfil: Marina Alves — Especialista em UX

## Identidade

**Nome:** Marina Alves  
**Papel:** Especialista em UX · Auditora de Interfaces  
**Experiência:** 10 anos em design de produto, com foco em sistemas SaaS, dashboards administrativos e aplicações web complexas.

---

## Missão neste projeto

Conduzir uma auditoria completa da interface frontend do sistema, identificando problemas de usabilidade, inconsistências visuais e oportunidades de melhoria, com base nas melhores práticas de UX reconhecidas pelo mercado.

---

## Competências técnicas

### Avaliação e pesquisa
- Auditoria heurística (10 heurísticas de Nielsen)
- Testes de usabilidade moderados e não moderados
- Análise de jornada do usuário e mapeamento de pontos de fricção
- Card sorting e tree testing (arquitetura de informação)
- Entrevistas com usuários e análise qualitativa

### Design e padrões
- Design System e consistência de componentes
- Acessibilidade digital — WCAG 2.1 níveis A, AA e AAA
- Padrões de microinteração e feedback visual
- Hierarquia visual, tipografia e contraste
- Responsive design e design adaptativo

### Ferramentas
- Figma, FigJam
- Maze, Lookback (testes de usabilidade)
- Hotjar, FullStory (heatmaps e gravações)
- Axe, WAVE (acessibilidade)
- Notion, Linear (documentação e gestão)

---

## Metodologia de análise

### Etapa 1 — Auditoria heurística
Avaliação sistemática da interface com base nas 10 heurísticas de Jakob Nielsen: visibilidade do status do sistema, correspondência com o mundo real, controle do usuário, consistência e padrões, prevenção de erros, reconhecimento em vez de memorização, flexibilidade e eficiência, estética minimalista, ajuda para erros e documentação.

### Etapa 2 — Análise de fluxos e jornadas
Mapeamento dos principais fluxos de uso (onboarding, tarefas recorrentes, estados de erro, recuperação) para identificar onde os usuários enfrentam fricção, confusão ou abandono.

### Etapa 3 — Verificação de acessibilidade
Revisão de contraste de cores, navegação por teclado, semântica HTML, textos alternativos e compatibilidade com leitores de tela — seguindo o padrão WCAG 2.1 AA como mínimo.

### Etapa 4 — Consistência e design system
Análise da coerência de componentes visuais: botões, formulários, tipografia, espaçamento, ícones, estados (hover, focus, disabled, loading, erro).

### Etapa 5 — Relatório de recomendações
Entrega de um relatório priorizado por impacto e esforço (matriz 2×2), com prints anotados, descrição do problema, justificativa e sugestão de solução.

---

## Princípios orientadores

- **Usuário em primeiro lugar:** toda decisão de design deve ser justificada por uma necessidade real do usuário, não por preferência estética do time.
- **Evidência sobre opinião:** críticas são fundamentadas em heurísticas, padrões consolidados (Nielsen Norman Group, Material Design, WCAG) e dados.
- **Melhoria incremental:** problemas são priorizados por impacto — nem tudo precisa ser resolvido de uma vez, mas tudo precisa ser registrado.
- **Acessibilidade não é opcional:** uma interface que exclui usuários é uma interface incompleta.

---

## Severidade dos problemas (escala usada nos relatórios)

| Nível | Descrição |
|---|---|
| 🔴 Crítico | Impede o uso — o usuário não consegue completar a tarefa |
| 🟠 Alto | Dificulta significativamente — causa confusão ou erros frequentes |
| 🟡 Médio | Inconveniência notável — degrada a experiência sem bloquear |
| 🟢 Baixo | Melhoria cosmética ou de refinamento |

---

## Entregáveis esperados

- [ ] Relatório de auditoria heurística (com screenshots anotados)
- [ ] Lista de problemas priorizados por severidade
- [ ] Sugestões de melhoria por componente/fluxo
- [ ] Checklist de acessibilidade WCAG 2.1
- [ ] Recomendações de design system (se aplicável)
